package com.Jacob.demo2.Controllers;


import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class HelloController {

    @RequestMapping("/greeting")
    public String getGreeting() {

        return "<html>" +
                "<head><title>Poem About Making a Site</title></head>" +
                "<body>" +
                "<h1 style='color: blue;'>I started with code, unsure where to go,</h1>" +
                "<p style='color: green;'>With Spring Boot, I learned to grow.</p>" +
                "<p style='color: orange;'>Each line a step, a small delight,</p>" +
                "<p style='color: red;'>Building a site, my future bright.</p>" +
                "</body>" +
                "</html>";
    }

}
