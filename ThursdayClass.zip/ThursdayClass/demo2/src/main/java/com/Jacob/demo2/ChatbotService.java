package com.Jacob.demo2;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import org.springframework.http.*;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;

@Service
public class ChatbotService {

    @Value("${chatbot.api.key}")
    private String apiKey;

    @Value("${chatbot.api.url}")
    private String apiUrl;

    private final RestTemplate restTemplate;

    public ChatbotService(RestTemplate restTemplate) {
        this.restTemplate = restTemplate;
    }

    public String getResponseFromChatbot(String userMessage) {
        // Prepare headers
        HttpHeaders headers = new HttpHeaders();
        headers.set("Authorization", "Bearer " + apiKey);
        headers.setContentType(MediaType.APPLICATION_JSON);

        // Prepare body
        String jsonBody = "{"
                + "\"model\": \"gpt-3.5-turbo\","
                + "\"messages\": [{\"role\": \"user\", \"content\": \"" + userMessage + "\"}]}";

        HttpEntity<String> entity = new HttpEntity<>(jsonBody, headers);

        // Send request to the OpenAI API
        ResponseEntity<String> response = restTemplate.exchange(apiUrl, HttpMethod.POST, entity, String.class);

        // Parse and return the response from OpenAI (assuming it comes in a predictable format)
        String chatbotResponse = response.getBody();

        // You would typically parse the response JSON here, but for simplicity we'll just return the raw response
        return chatbotResponse;
    }
}

